package com.example.hww6_6488148

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
